# Amazing shoes
The code that goes with [this video](https://www.youtube.com/watch?v=X1dz0xRbSJc&)
